package com.wipro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAccountTracker20363674ApplicationTests {

	@Test
	void contextLoads() {
	}

}
