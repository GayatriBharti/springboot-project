package com.wipro.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.wipro.model.Account;
import com.wipro.model.Customer;
import com.wipro.repository.CustomerRepository;


@ExtendWith(MockitoExtension.class)

@SpringBootTest
class CustomerServiceTest {

	@InjectMocks
	//junit test on customerservices 
	CustomerService customerService;
	
	@Mock
	//we are get dummy object of customerrepository
	CustomerRepository customerRepo;
	
	
	@Test
	public void updateCustomerTest() 
	{
		//Give
		Customer existingcustomer= customerRepo.findById(1).orElse(getCustomer());
		
		   existingcustomer.setCustomername("bharti");
	     //when
		   when(customerRepo.save(any())).thenReturn(existingcustomer);
		   //Assert test
	       Customer customerUpdated = customerService.update(existingcustomer);
	       assertEquals(existingcustomer,customerUpdated);
	

		
	}
	
	
	
	@Test
	public void addCustomerTest() {
		
		
		//Bank expectedbank=new Bank();
		//expectedbank.setCustomer(getCustomer());
		Customer expectedcustomer= getCustomer();
		
		when(customerRepo.save(any())).thenReturn(expectedcustomer);
		// when(customerRepo.save(bank.getCustomer())).thenReturn(getCustomer());
		Customer  actual=customerService.save(expectedcustomer);
		assertEquals(expectedcustomer,actual);
	}
	
	
	@Test
	public void getAllCustomersTest() 
	{
		List<Customer> expected= getCustomerList();
	    when(customerRepo.findAll()).thenReturn(expected);
	    List<Customer> actual=customerService.getAllCustomers();
	    assertEquals(expected,actual);
			
	}
	@Test
	public void getCustomersBynameTest() 
	{
		List<Customer> expected= getCustomerList1();
	    when(customerRepo.findBycustomername("gayatri")).thenReturn(expected);
	    List<Customer> actual=customerService.getCustomerbyname("gayatri");
	    assertEquals(expected,actual);
			
	}
	@Test
	public void getCustomersBycityTest() 
	{
		List<Customer> expected= getCustomerList1();
	    when(customerRepo.findAllBycityname("patna")).thenReturn(expected);
	    List<Customer> actual=customerService.getCustomerBycityname("patna");
	    assertEquals(expected,actual);
			
	}
	@Test
	public void getCustomersBymobilenoTest() 
	{
		List<Customer> expected= getCustomerList1();
	    when(customerRepo.findBymobileno(926448)).thenReturn(expected);
	    List<Customer> actual=customerService.getCustomerbymobileno(926448);
	    assertEquals(expected,actual);
			
	}
	@Test
	public void getCustomersByidTest() 
	{
		Optional<Customer> expected = Optional.ofNullable(new Customer(1,"gayatri","patna",926448,getAccountList1()));
	    when(customerRepo.findById(1)).thenReturn(expected);
	    Optional<Customer> actual=customerService.getCustomerbyid(1);
	    assertEquals(expected,actual);
			
	}
	@Test
	public void deleteCustomerByid() 
	{
		
	    
	    customerService.deletecustomerById(1);
	    verify(customerRepo,times(1)).deleteById(1);;
	}
	@Test
	public void deleteCustomerAll() 
	{
		
	    
	    customerService.deleteallcustomer();
	    verify(customerRepo,times(1)).deleteAll();;
	}

	public Customer getCustomer()
	{
	    	
		Customer customer1=new Customer();
 	    customer1.setCustomerid(1);
 	    customer1.setCustomername("gayatri");
 	    customer1.setCityname("patna");
 	    customer1.setMobileno(926448);
 	    customer1.setAccounts(getAccountList1());
	    	    
			return customer1;
	}
	  
	
    public List<Customer> getCustomerList(){
    	
    	List<Customer> customerlist=new ArrayList();
    	   Customer customer1=new Customer();
    	   customer1.setCustomerid(1);
    	   customer1.setCustomername("gayatri");
    	   customer1.setCityname("patna");
    	   customer1.setMobileno(926448);
    	   customer1.setAccounts(getAccountList1());
    	   Customer customer2=new Customer();
    	   customer2.setCustomerid(1);
    	   customer2.setCustomername("duggu");
    	   customer2.setCityname("Kolkata");
    	   customer2.setMobileno(45678);
    	   customer2.setAccounts(getAccountList2());
    	   
         customerlist.add(customer1);
         customerlist.add(customer2);
    	 
		return customerlist;
    }
public List<Customer> getCustomerList1(){
    	
    	List<Customer> customerlist=new ArrayList();
    	   Customer customer1=new Customer();
    	   customer1.setCustomerid(1);
    	   customer1.setCustomername("gayatri");
    	   customer1.setCityname("patna");
    	   customer1.setMobileno(926448);
    	   customer1.setAccounts(getAccountList1());
    	   
         customerlist.add(customer1);
    	 
		return customerlist;
    }
    public List<Account> getAccountList1(){
    	
    	List<Account> accountlist=new ArrayList();
    	Account account1=new Account();
    	
    	account1.setAccountid(101);
    	account1.setAccountno(12);
    	account1.setAccounttype("saving");
    	account1.setAccountbalance(50000);
    	return accountlist;
    	
    }
	public List<Account> getAccountList2(){
	    	
	    	List<Account> accountlist=new ArrayList();
	    	
	    	
	    	Account account2 =new Account();
	    	
	    	account2.setAccountid(102);
	    	account2.setAccountno(18);
	    	account2.setAccounttype("current");
	    	account2.setAccountbalance(1000);
	    	accountlist.add(account2);
	    	
	    	return accountlist;
	    	
    }
    
    

}
