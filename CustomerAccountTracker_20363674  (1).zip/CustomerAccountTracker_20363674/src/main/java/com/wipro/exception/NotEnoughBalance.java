package com.wipro.exception;

public class NotEnoughBalance extends Exception {

	public NotEnoughBalance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NotEnoughBalance(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
