package com.wipro.exception;

public class ResourceNotFoundException extends Exception {

	
	public ResourceNotFoundException() {
		// TODO Auto-generated constructor stub
		super();
	}
	
	public ResourceNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
}
