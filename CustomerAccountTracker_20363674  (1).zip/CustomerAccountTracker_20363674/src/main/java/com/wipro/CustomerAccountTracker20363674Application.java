package com.wipro;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EnableJpaRepositories
@SpringBootApplication
public class CustomerAccountTracker20363674Application {

	public static void main(String[] args) {
		SpringApplication.run(CustomerAccountTracker20363674Application.class, args);
		System.out.println("customer account tracker");
	}

}
