package com.wipro.service;


import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RestController;

import com.wipro.model.Account;
import com.wipro.model.Customer;
import com.wipro.model.Transaction;
import com.wipro.repository.AccountRepository;
import com.wipro.repository.CustomerRepository;

@Service
//@RestController
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private AccountRepository accountRepo;

	
	public List<Customer> getAllCustomers()
	{
		List<Customer> list=customerRepo.findAll();
		return 	list;
	}
	
	
	public Optional<Customer> getCustomerbyid(int customerid)
	{
		
		return customerRepo.findById(customerid);	
	}
	
	public Customer save(Customer customer) {
		return customerRepo.save(customer);
	}

	
	public String getCustomerbyidstring(int customerid)
	{
		
		return customerRepo.findById(customerid).toString();	
	}
	
	public Customer update(Customer customer) 
	{
		Customer existingCustomer = customerRepo.findById(customer.getCustomerid()).orElse(null);
		return customerRepo.save(existingCustomer);
		
	}
	public List<Customer> getCustomerbyname(String customername)
	{
		
		return customerRepo.findBycustomername(customername);	
	}
	public List<Customer> getCustomerbymobileno(int mobileno)
	{
		
		return customerRepo.findBymobileno(mobileno);	
	}

	public void deletecustomerById(int customerid) {
		customerRepo.deleteById(customerid);
	}
	
	public void deleteallcustomer()
	{
		customerRepo.deleteAll();
	}
	public List<Customer> getCustomerBycityname(String cityname)
	{
		
		return customerRepo.findAllBycityname(cityname);	
	}
	
	
	  public String transferMoney(Transaction transaction) {
			
			Optional<Account> accountFrom = accountRepo.findById(transaction.getFromaccountid());
			
			Optional<Account> accountTo = accountRepo.findById(transaction.getToaccountid());
			
			int availableFromAmount = accountFrom.get().getAccountbalance();
			
			int availableToAmount = accountTo.get().getAccountbalance();
			
			if(availableFromAmount >= transaction.getAmountToTransfer()) {
				
				
				// Debit from From account
				
				accountFrom.get().setAccountbalance(availableFromAmount-transaction.getAmountToTransfer());
				accountRepo.save(accountFrom.get());
				
				//Credit to To account
				
				accountTo.get().setAccountbalance(availableToAmount+transaction.getAmountToTransfer());
				accountRepo.save(accountTo.get());
				
				return "Amount Transferred sucessfully";
			}
			else {
				return "Amount is insufficient in From Account Id";
			}
			
			
		}

	
}
