package com.wipro.model;




public class Transaction {
	
	
	private int fromaccountid;
	private int toaccountid;
	private int amountToTransfer;
	
	public int getFromaccountid() {
		return fromaccountid;
	}
	public void setFromaccountid(int fromaccountid) {
		this.fromaccountid = fromaccountid;
	}
	public int getToaccountid() {
		return toaccountid;
	}
	public void setToaccountid(int toaccountid) {
		this.toaccountid = toaccountid;
	}
	public int getAmountToTransfer() {
		return amountToTransfer;
	}
	public void setAmountToTransfer(int amountToTransfer) {
		this.amountToTransfer = amountToTransfer;
	}
	
		
	public Transaction(int fromAccountId, int toaccountid, int amountToTransfer) {
		super();
		this.fromaccountid = fromaccountid;
		this.toaccountid = toaccountid;
		this.amountToTransfer = amountToTransfer;
	}
	
	
	@Override
	public String toString() {
		return "TransferRequest [fromAccountId=" + fromaccountid + ", toAccountId=" + toaccountid
				+ ", amountToTransfer=" + amountToTransfer + "]";
	}
}